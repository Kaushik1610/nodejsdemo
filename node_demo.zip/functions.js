connection = require('./connection');
var randomstring = require("randomstring");
var api_key = 'key-5728179e2596222d9e82b07228a09cf9';
var asyncLoop = require('node-async-loop');
var async = require('async');
var fs = require('fs');

var image_url = "image/"; 

var postArticle = function (req,res)
{
	var response = [];
 	if (req.body.name != '' && req.body.title != '' && req.body.content != '') 
 	{	
 		console.log(req.body.name);


		connection.query('INSERT INTO tbl_blog(name, title , content) VALUES (?,?,?)',[req.body.name, req.body.title, req.body.content],  function(err, result,test ) {
			if(!err)
			{
				response = {'status':'1','msg' : 'New artile has been successfully posted.'};
				res.setHeader('Content-Type', 'application/json');
	    		res.status(200).send(JSON.stringify(response));

		    	
			} else {
				response = {'status':'0','msg' : 'something went wrong!!!'};
				res.setHeader('Content-Type', 'application/json');
		    	res.status(400).send(JSON.stringify(response));

			}
		});
	} 
	else 
	{
		response.push({'result' : 'error', 'msg' : 'Please fill required details'});
		res.setHeader('Content-Type', 'application/json');
		res.status(400).send(JSON.stringify(response));
	}
}

var getArticle = function (req,res)
{
	var page = req.body.page_no;

	if(page==0){ page = 1;}
	var totalRow = 0;
	var LIMIT = 2;
	offset = (page - 1) * LIMIT;
	totalLike = 0;
	islike = 0;
	var response_data = [];
	var path_name = req.url;

	connection.query('select SQL_CALC_FOUND_ROWS  tbl_blog.* FROM tbl_blog WHERE status = "y" ORDER BY id desc  limit '+offset+','+LIMIT,  function(err, rows, fields ) 
	{
		connection.query('select FOUND_ROWS() as total',function(err,result,field)
		{
			asyncLoop(rows, function (item, next)
			{
    				var obj = {
						'id'        	: item.id, 
						'name'        	: item.name,
						'title'        	: item.title,
						'content'       : item.content,
						'created'       : item.created,
					};
					response_data.push(obj);
			    
				next();
			});
			
			if(!err)
	  		{
	  			var response = [];
				if(rows.length != 0) 
				{
				totalPage=  Math.ceil(rows.length / LIMIT); 

				response = {'status'     : '1',
							'message'    : 'success',
							'currentPage': page,
							'totalPage'  : totalPage,
							'totalRow'   : rows.length,
							'data'       : response_data
							};
			} 
			else 
			{
				response = {'status':'0','msg' : 'No Result Found'};
			}
			res.setHeader('Content-Type', 'application/json');
	    	res.status(200).send(JSON.stringify(response));
	  	}
	  	else 
	  	{
			res.status(400).send(err);
		}
	});
	});
}

var postCommentOnArticle = function (req,res)
{
	var response = [];
 	if (req.body.blog_id != '' && req.body.comment != '') 
 	{
		var blog_id      = req.body.blog_id;
		var comment    = req.body.comment;
		
		connection.query('INSERT INTO tbl_comment(blog_id , comment ) VALUES (?,?)',[blog_id, comment],  function(err, result,test ) {
		
		if(!err)
		{
			response = {'status':'1','msg' : 'Comment posted successfully'};
			res.setHeader('Content-Type', 'application/json');
    		res.status(200).send(JSON.stringify(response));
		} 
		else 
		{
			response = {'status':'0','msg' : 'something went wrong!!!'};
			res.setHeader('Content-Type', 'application/json');
	    	res.status(400).send(JSON.stringify(err));

		}
					
		});
	} 
	else 
	{
		response.push({'result' : 'error', 'msg' : 'Please fill required details'});
		res.setHeader('Content-Type', 'application/json');
		res.status(400).send(JSON.stringify(response));
	}
}


var postCommentOnReply = function (req,res)
{
	var response = [];
 	if (req.body.comment_id != '' && req.body.comment != '') 
 	{
		var comment_id  = req.body.comment_id;
		var comment     = req.body.comment;
		
		connection.query('INSERT INTO tbl_comment_reply(comment_id , comment ) VALUES (?,?)',[comment_id, comment],  function(err, result,test ) {
		
		if(!err)
		{
			response = {'status':'1','msg' : 'Comment reply posted successfully'};
			res.setHeader('Content-Type', 'application/json');
    		res.status(200).send(JSON.stringify(response));
		} 
		else 
		{
			response = {'status':'0','msg' : 'something went wrong!!!'};
			res.setHeader('Content-Type', 'application/json');
	    	res.status(400).send(JSON.stringify(err));

		}
					
		});
	} 
	else 
	{
		response.push({'result' : 'error', 'msg' : 'Please fill required details'});
		res.setHeader('Content-Type', 'application/json');
		res.status(400).send(JSON.stringify(response));
	}
}

var getArticleComment = function (req,res)
{
	var page = req.body.page_id;
	var blog_id = req.body.blog_id;
	if(page==0) { page = 1;}
	var totalRow = 0;
	var LIMIT = 5;
	offset = (page - 1) * LIMIT;
	
	totalLike = 0;
	var response_data = [];
	connection.query('select tbl_comment.* FROM tbl_comment WHERE blog_id = '+blog_id+' ',  function(err, rows, fields ) 
	{
			if(!err)
	  		{
	  			var response = [];
				if(rows.length != 0) 
				{
				totalPage=  Math.ceil(totalRow / LIMIT); 
				response = {
					'status'  : '1',
					'message' : 'success',
					'data'   : rows
				};
			} 
			else 
			{
				response = {'status':'0','msg' : 'No Result Found'};
			}
			res.setHeader('Content-Type', 'application/json');
	    	res.status(200).send(JSON.stringify(response));
	  	}
	  	else 
	  	{
			res.status(400).send(err);
		}
	});
}

module.exports.postArticle = postArticle;	
module.exports.getArticle = getArticle;	
module.exports.postCommentOnArticle = postCommentOnArticle;
module.exports.getArticleComment = getArticleComment;
module.exports.postCommentOnReply = postCommentOnReply;




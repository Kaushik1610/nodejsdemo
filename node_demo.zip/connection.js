var mysql = require('mysql');

var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "node_api_demo" 
});
connection.connect()
module.exports = connection
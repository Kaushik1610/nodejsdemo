var http     = require('http');
var express  = require('express');
var parser   = require('body-parser');
var routs     = require('./functions');

var path = require("path");
var fs = require("fs");

var app = express();
app.use(parser.json());
app.use(parser.urlencoded({ extended: true }));
app.set('port', process.env.PORT || 5000);
 
app.use(express.static(__dirname + "/"));
app.use(parser.urlencoded({ extended: false }));

app.use(express.static(__dirname + '/public'));

// Set default route
app.get('/', function (req, res) {
	res.send('<html><body><p>Welcome to Node JS API Demo</p></body></html>');
});
 
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
}); 


// Create server
http.createServer(app).listen(app.get('port'), function(){
	console.log('Server listening on port ' + app.get('port'));
});


app.post('/postArticle', function (req,res) 
{
	routs.postArticle(req,res);
});

app.post('/getArticle', function (req,res) 
{
	routs.getArticle(req,res);
});

app.post('/postCommentOnArticle', function (req,res) 
{
	routs.postCommentOnArticle(req,res);
});

app.post('/getArticleComment', function (req,res) 
{
	routs.getArticleComment(req,res);
});

app.post('/postCommentOnReply', function (req,res) 
{
	routs.postCommentOnReply(req,res);
});


